function [conc,fstat,resp,resw,errp,err0,fits] = FitCandSpectra(x,keptspec,candspec,cconind,ccov,p)
%FITCANDSPECTRA Fits Candidate Spectra for a Single Step in Forward Stepwise CLS
%  For a matrix of initial kept spectra (keptspec) and a set of new
%  candidate spectra (candspec), FITCANDSPECTRA fits [keptspec; candspec(k,:)]
%  for k=1,...,K to the spectra in (x) i.e., the  each candidate spectrum
%  is tested one at a time. The results of an F-test (Chow test) for fit
%  significance are output in (fstat). The estimated concentrations (conc)
%  for each fit is a three-way array when (x) has more than one row.
%
%  The fit is based on non-negatively constrained classical least squares
%  (CLS). Non-negativity can be relaxed using the input (cconind).
%
%  INPUT:
%           x = 1xN measured spectra (class DataSet).
%    keptspec = KpxN matrix of kept spectra, (keptspec) can be empty
%               (class DataSet).
%    candspec = KxN matrix of candidate spectra (class DataSet).
%  
%  OPTIONAL INPUTS:
%     cconind = 1x(Kp+K) vector indicate which elements of (c) are to be
%               non-negatively constrained. If (cconind) is empty then it
%               is set to ones(1,Kp+K) indcating non-negatively constrained.
%               See FASTERNNLS.
%        ccov = {[]}, NxN weight matrix, e.g.,ccov = spdiag(wt) where (wt)
%               is a weighting matrix (0<=w<=1). The objective function is
%               O(c) = (x-Sc)'*diag(wts.^2)*(x-Sc). See SETWEIGHTS.
%           p = { 0.95 }, the probability point for the F-test 0<p<1.
%
%  OUTPUTS:
%        conc = Kx(Kp+1) array of concentrations (class DataSet).
%               (Samples by Candidate Spectra by Concentrations).
%       fstat = Kx2 matrix of F-statistics: Column 1 is from the Chow test
%                 and Column 2 is a residual ratio (class DataSet).
%        resp = KxN residuals for each candidate spectrum.
%        resw = KxN weighted residuals for each candidate spectrum.
%        errp = Kx1 matrix of fit sum-squared residuals (ssq) (class DataSet).
%               If ~isempty(cov), the it is the weighted ssq.
%        err0 = 1x1 scalar of residuals prior to fitting candidate spectra
%               (class DataSet).
%     fits = KxN array of fits (class DataSet).
%               (Samples by Candidate Spectra by number of spectral channels).
%
%I/O: [conc,fstat,resp,resw,errp,err0,fits] = FitCandSpectra(x,keptspec,candspec,cconind,ccov,p);
%
%See also: CLS_ISPEC, FASTERNNLS, FTEST, SETWEIGHTS

%% Check I/O
m     = size(x);
if m(1)>1
  error('Input (x) can have only one row.')
end
kp    = size(keptspec,1);
k     = size(candspec,1);
inc2  = candspec.include{2};
if nargin<4
  cconind = ones(1,k+kp);
end
if nargin<5
  ccov    = [];
end
if nargin<6 || isempty(p)
  p       = 0.95;
end

%% Initialize Variables
if isempty(keptspec)
  if isempty(ccov)
    err0    = sum(x.data(:,inc2).^2,2);
  else
    err0    = sum((x.data(:,inc2)*ccov(inc2,inc2)).^2,2);
  end
else %%%RIOGHT HERE
  if isempty(ccov) % reuse var conc
    conc    = fasternnls(keptspec.data(:,inc2)',x.data(:,inc2)',[],[],[],cconind(1:kp))';
    err0    = sum((x.data(:,inc2)-conc*keptspec.data(:,inc2)).^2,2);
  else
    conc    = fasternnls(ccov(inc2,inc2)*keptspec.data(:,inc2)', ...
                             ccov(inc2,inc2)*x.data(:,inc2)',[],[],[],cconind(1:kp))';
    err0    = sum(((x.data(:,inc2)-conc*keptspec.data(:,inc2))*ccov(inc2,inc2)).^2,2);
  end
end
conc  = NaN(k,kp+1);
errp  = NaN(k,1);
resp  = zeros(k,m(2));
resw  = resp;
spec  = [keptspec; candspec];
fits  = NaN(k,m(2));

%% Calculation Loop Fits Over Candidate Spectra
if isempty(ccov)
  for i2=1:k
    conc(i2,:)    = fasternnls(spec.data([1:kp kp+i2],inc2)',x.data(:,inc2)',[],[],[],cconind([1:kp i2]))';
    fits(i2,inc2) = conc(i2,:)*spec.data([1:kp kp+i2],inc2);
    resp(i2,inc2) = x.data(:,inc2)-fits(i2,inc2);
    resw(i2,inc2) = resp(i2,inc2);
    errp(i2,1)    = sum(resp(i2,:).^2,2);
  end
else
  for i2=1:k
    conc(i2,:)    = fasternnls(ccov(inc2,inc2)*spec.data([1:kp kp+i2],inc2)', ...
                               ccov(inc2,inc2)*x.data(:,inc2)',[],[],[],cconind([1:kp i2]))';
    fits(i2,inc2) = conc(i2,:)*spec.data([1:kp kp+i2],inc2);
    resp(i2,inc2) = x.data(:,inc2)-fits(i2,inc2);
    resw(i2,inc2) = resp(i2,inc2)*ccov(inc2,inc2);
    errp(i2,1)    = sum(resw(i2,inc2).^2,2);
  end
end

fstat = zeros(k,2);
fstat(:,1)  = ((err0*ones(k,1)-errp)./(errp/(m(2)-kp-k)))/ftest(1-p,1,m(2)-kp-k); %Chow test
fstat(:,2)  = (err0./errp)/ftest(1-p,m(2)-kp,m(2)-kp-1);                          %residual ratio test

%% Creat DSOs
conc  = copydsfields(candspec,dataset(conc),1);
conc.name         = ['Est Conc for ',x.name];
conc.labelname{1} = 'Candidate Spectrum';
if kp>0
  if ~isempty(keptspec.label{1})
    conc.label{2}   = char(keptspec.label{1},'Candidate');
  end
  conc.labelname{2} = 'Candidate Included';
end
resp  = copydsfields(x,dataset(resp),2);
resp  = copydsfields(candspec,resp,1);
if ~isempty(x.label{1})
  resp.name       = deblank(x.label{1}(1,:));
end
resw  = copydsfields(resp,dataset(resw));
fits  = copydsfields(resp,dataset(fits));

err0  = copydsfields(x,dataset(err0),1);
err0.labelname{1} = 'Sample';

errp  = copydsfields(conc,dataset(errp),1);

fstat = copydsfields(conc,dataset(fstat),1);
fstat.name        = 'F-Statistic';
fstat.label{2}    = {'Chow Test','Ratio'};

if isempty(ccov)
  err0.name       = 'SSQ Initial';
  errp.name       = 'SSQ Fit';
else
  err0.name       = 'Weighted SSQ Initial';
  errp.name       = 'Weighted SSQ Fit';
end
