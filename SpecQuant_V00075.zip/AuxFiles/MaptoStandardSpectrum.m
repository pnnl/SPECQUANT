function [sstd,sint,MapModel,plotdata] = MaptoStandardSpectrum(sstd,smes,opts)
%MAPTOSTANDARDSPECTRUM Identify a model for shifting the measured axisscale.
%  MAPTOSTANDARDSPECTRUM Identifies a model (MapModel) for shifting the
%  measured axis scale in (smeas) to the standard axis scale in (sstd).
%  Steps
%
%  MAPTOSTANDARDSPECTRUM is expects that the standard spectrum (sstd) will
%  have a wider wavenumber range than the measured spectrum (smes), and
%  trims the input standard spectrum (sstd) to the wavenumber range  
%    min(smes.axisscale{2})-opts.maxshift < sstd.axisscale{2} & < ...
%    min(smes.axisscale{2})+opts.maxshift.
%  
%  See APPLYMAPMODEL to apply the MapModel to new spectra.
%
%  INPUTS:
%    sstd = 1xN standard spectrum to map to (e.g., PNNL H2O spectrum)
%             [class "dataset"].
%    smes = in calibration: 1xP measured spectrum from Field instrument
%             (e.g., Opus measurements) where P<N [class "dataset"].
%    opts = required structure array for identifying MapModel (see
%             REGISTERSPEC).
%             Use I/O: opts = MaptoStandardSpectrum('options');
%             to obtain a default options structure.
%           In addtion to REGISTERSPEC options additional fields include:
%             peaklist = []; If not empty, this contains a string
%                        containing the full path name of the peak list to
%                        load. The peak list is a vector of indices corresponding
%                        to the standard database spectrum (e.g., H2O from PNNL).
%                        If empty then peak find options are used.
%                        
%             peakfind = peakfind('options'); OPTIONS STRUCTURE for the
%                        PEAKFIND function.
%       peakfind.width = number of points in Savitzky-Golay filter {default: tolfac = 7}.
%      peakfind.tolfac = tolerance on the estimated residuals, peaks heights
%                        are estimated to be > tolfac*noise level {default: tolfac = 7}.
%           peakfind.w = odd scalar window width for determining local maxima
%                        {default: w = 3} (see LOCALMAXIMA).
%   peakfind.algorithm = algorithm used to identify peak location. {default = 'd2'}
%                         (see PEAKFIND).
%
%                 iter = OPTIONS STRUCTURE goverining iteration over the
%                        REGISTERSPEC function.
%              reltol  = {1e-4} relative tolerance for change in fit.
%              itmax   = {10} maximum number of iterations.
%              winfac  = {0.8} 0<winfac<1 shrinkage factor for opts.window.
%
%  OUTPUTS:
%      tstd = 1xNt trimmed standard spectrum with axis scale on the range
%               [min(smeas.axisscale{2})-opts.maxshift max(smeas.axisscale{2})+opts.maxshift]
%               where P<Nt<=N .
%               Only min(smeas.axisscale{2}):max(smeas.axisscale{2})
%               included in the output DSO.
%      sint = 1xNt measured spectrum interpolated and shifted to the
%               standard axisscale. Extrapolated "ends" are set to 0 (zero).
%               Only min(smeas.axisscale{2}):max(smeas.axisscale{2})
%               included in the output DSO.
%  MapModel = structure array with the following fields:
%       axaxis: 1xNt axis scale from (tstd).
%      foundat: vector of peak shifts found for each peak (see REGISTERSPEC).
%     shiftfns: vector of corrections made to axisscal (see REGISTERSPEC).
%     maxshift: opts.maxshift (see REGISTERSPEC).
%       window: opts.window (see REGISTERSPEC).
%    algorithm: opts.algorithm {default = 'poly'} (see REGISTERSPEC).
%        order: opts.order (see REGISTERSPEC).
%           i0: peak locations in sstd (see PEAKFIND) BEFORE (sstd) is trimmed.
%        incl2: tstd.include{2}, used in APPLYMAPMODEL to set include{2} field
%  plotdata = structure with the following fields:
%    usedpeaks: MapModel.usedpeaks.
%      foundat: MapModel.foundat.
%        xaxis: sstd.axisscale{2}.
%      fitline: shift model results (e.g., from polyval(pp,sstd.axisscale{2})
%                  or ppval(pp,sstd.axisscale{2}).
%  axusedpeaks: location of peaks used for transform (x-axis units).
%  axusedfound: location of peaks found w/in the first window for transform (x-axis units).
%  description: desription of how the output plotdata can be used (character array).
%
%I/O: [tstd,sint,MapModel,plotdata] = MaptoStandardSpectrum(sstd,smes,opts);
%I/O: opts = MaptoStandardSpectrum('options');
%
%See also: APPLYMAPMODEL, LOCALMAXIMA, PEAKFIND, REGISTERSPEC

% 3/3/22 added MapModel.inc2 field (corresponds to tstd.include{2}

%     makeplots = [true | {false}] governs plotting of the model results.

if nargin == 0; sstd = 'io'; end
if ischar(sstd)
  opts    = registerspec('options');
  opts.peaklist     = [];
  opts.peakfind     = peakfind('options');
  opts.peakfind.width        = 7; %9;
  opts.peakfind.tolfac       = 7; %5;
  opts.peakfind.w            = 3;
  opts.peakfind.algorithm    = 'd2';
  opts.reltol       = 1e-4;       % relative tolerance for change in fit.
  opts.itmax        = 10;         % maximum number of iterations.
  opts.winfac       = 0.8;        % 0<winfac<1 shrinkage factor for opts.window.
  opts.functionname = 'MaptoStandardSpectrum';
  
  if nargout==0; evriio(mfilename,sstd,opts); clear sstd; 
  else; sstd = evriio(mfilename,sstd,opts); end
  return;
end
opts      = reconopts(opts,mfilename);

m         = size(sstd);  %before trimming
if size(smes,1)~=m(1)
  error('Input size(smeas,1) must = size(sstd,1).')
end

%% Apply interpolation and determine shifting Field to Master

MapModel.name = 'MapModel';
MapModel.axaxis   = [];
MapModel.foundat  = [];
MapModel.shiftfns = [];
MapModel.maxshift = opts.maxshift;
MapModel.window   = opts.window;
MapModel.algorithm  = opts.algorithm;
MapModel.order    = opts.order;
MapModel.i0       = [];
MapModel.incl2    = [];

% Find min and max wavenumber for measured spectrum
low       = min(smes.axisscale{2});                  %minimum of measured spectrum
high      = max(smes.axisscale{2});                  %maximum of measured spectrum

% Trim sstd spectrum
sstd      = sstd(:,sstd.axisscale{2}>low -opts.maxshift & ...
                   sstd.axisscale{2}<high+opts.maxshift);   %trimmed standard sepctrum (tstd)
sstd      = delsamps(sstd,find(sstd.axisscale{2}<low), 2,1);
sstd      = delsamps(sstd,find(sstd.axisscale{2}>high),2,1);
m         = size(sstd); % after trimming

% Interpolate the measured spectrum to the standard axis
sint      = Mapinterp(sstd,smes);                    %interepolated measured spectrum

if opts.maxshift>0 % Shift measured spectrum to standard spectrum
  % Find major peaks to fit to
  if isempty(opts.peaklist)
    i0    = peakfind(sstd.data(1,:),opts.peakfind.width,opts.peakfind.tolfac, ...
                         opts.peakfind.w,opts.peakfind);
    i0    = i0{1};
    % save('H2O_Peak_List','i0')
  else
    i0    = load(opts.peaklist);
    fn    = fieldnames(i0);
    if length(fn)>1
      error('Peak List must be a vector')
    end
    i0    = getfield(i0,fn{1});
  end
  MapModel.i0       = i0;
  
  % Check if multiple spectra are used
  if m(1)>1 
    sstd.data(1,:)  = sum(sstd.data);
    sstd            = sstd(1,:);
    sint.data(1,:)  = sum(sint.data);
    sint            = sint(1,:);
  end

  % Shift measured spectrum to standard spectrum
  optr      = registerspec('options');
  optr.display      = 'off';
  optr.plots        = opts.plots;
  optr.interpolate  = [];   %[] or <0 does no interpolation, > 0 performs interpolation
  optr.maxshift     = opts.maxshift;
  optr.window       = opts.window;
  optr.order        = opts.order;
  optr.algorithm    = opts.algorithm;
  optr.smoothing    = opts.smoothing;
  optr.smoothinfo   = opts.smoothinfo;
  optr.iter.reltol  = 1e-4;
  optr.iter.itmax   = 10;
  optr.iter.winfac  = 0.6; % 0<winfac<1 window shrinkage factor
  MapModel.shiftfns = zeros(optr.iter.itmax,m(2));
  pause off
  [sint,MapModel.axaxis,MapModel.foundat,MapModel.shiftfns(1,:),MapModel.usedpeaks] = registerspec(sint,[],sstd.axisscale{2}(i0),optr);
  shifting          = true;
  it                = 1;
  while shifting && it<optr.iter.itmax
    it      = it+1;
    [sint,MapModel.axaxis,~,MapModel.shiftfns(it,:),MapModel.usedpeaks] = registerspec(sint,[],sstd.axisscale{2}(i0),optr);
    optr.window     = optr.window*optr.iter.winfac;
    if (sum(MapModel.shiftfns(it,:))/sum(MapModel.shiftfns(it-1,:)))<optr.iter.reltol || optr.window<abs(optr.shiftby)
      shifting      = false;
    end
  end
  pause on
  MapModel.shiftfns = sum(MapModel.shiftfns,1);

  [~,mi]    = max(sstd.axisscale{2});
  sstd      = delsamps(sstd,sstd.axisscale{2}>=sstd.axisscale{2}(mi)-optr.maxshift-MapModel.shiftfns(mi)-1,2,1);
  [~,mi]    = min(sstd.axisscale{2});
  sstd      = delsamps(sstd,sstd.axisscale{2}<=sstd.axisscale{2}(mi)+optr.maxshift+MapModel.shiftfns(mi)+1,2,1);
  sint.include{2}   = sstd.include{2};
  MapModel.incl2    = sstd.include{2};
  plotdata  = ShiftPlots(MapModel,sstd);
  
else
  disp('opts.maxshift<=0 No Shift found')
  %NOTE: May need to include a usable MapModel...
end

end %MaptoStandardSpectrum
            