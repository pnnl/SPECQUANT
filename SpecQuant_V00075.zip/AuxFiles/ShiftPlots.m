function [plotdata] = ShiftPlots(MapModel,sstd,makeplots)
%SHIFTPLOTS plots REGISTERSPEC peak model results.
%
%  INPUTS:
%    MapModel = Map Model output by MAPTOSTANDARDSPECTRUM.
%    sstd = Trimmed database spectrum used for shift modeling (e.g., H2O).
%
%  OUTPUT:
%    plotdata = structure with the following fields:
%      usedpeaks: MapModel.usedpeaks
%        foundat: MapModel.foundat
%          xaxis: sstd.axisscale{2}
%        fitline: shift model results (e.g., from
%                 polyval(pp,sstd.axisscale{2}) or ppval(pp,sstd.axisscale{2}).
%Example:
%   figure('Name','PeakShiftFit','Color',[1 1 1])
%   hh    = zeros(1,3);
%   hh(1) = plot(plotdata.xaxis(MapModel.i0),MapModel.foundat,'or'); hold on
%   hh(2) = plot(plotdata.axusedpeaks,plotdata.axusedfound,'ob');
%   hh(3) = plot(MapModel.axaxis, plotdata.fitline,'-','Color',[0.85 0.325 0.098]);
%   legend(hh,'Peak List','Used Peaks','Shift Model')
%   legend('AutoUpdate','off')
%   gh    = hline;
%   gh.Color = [1 1 1]*0.8;
%   uistack(gh,'bottom')
%   set(gca,'XDir','reverse')
%   xlabel('Wavenumber (cm^{-1})','Interpreter','tex')
%   ylabel('Peak Shift (cm^{-1})','Interpreter','tex')
%
%I/O: plotdata = ShiftPlots(MapModel,sstd);
%
%See also: MAPTOSTANDARDSPECTRUM, REGISTERSPEC

%3/3/22 modified help and description

if nargin<3
  makeplots        = false;
end
plotdata.usedpeaks  = MapModel.usedpeaks;
plotdata.foundat    = MapModel.foundat;
plotdata.xaxis      = sstd.axisscale{2};
plotdata.fitline    = MapModel.shiftfns;
indi                = findindx(sstd.axisscale{2},MapModel.usedpeaks); %Used Indices on the full axisscale
[indx,inix]         = intersect(MapModel.i0,indi); %intersect original
plotdata.axusedpeaks  = sstd.axisscale{2}(indx);
plotdata.axusedfound  = MapModel.foundat(inix);
plotdata.description  = char({'hh    = zeros(1,3);'; ...
                         'hh(1) = plot(plotdata.xaxis(MapModel.i0),MapModel.foundat,''or''); hold on';
                         '  % gives the position for the original peak list.';
                         'hh(2) = plot(plotdata.axusedpeaks,plotdata.axusedfound,''ob'');'
                         '  % gives the position of the peaks used for modeling.';
                         'hh(3) = plot(MapModel.axaxis,plotdata.fitline);';
                         '  % gives the shift model.'; ...
                         'legend(hh,''Peak List'',''Used Peaks'',''Shift Model'')'});

if makeplots
  figure('Name','ShiftPlot','Color',[1 1 1])
  iax   = find(plotdata.xaxis>530 & plotdata.xaxis<4100);
  plot(sstd.axisscale{2}(iax),normaliz(sstd.data(iax)))
  set(gca,'XDir','reverse')
  vline(sstd.axisscale{2}(MapModel.i0))
  vline(MapModel.usedpeaks,'r')
  legend('H2O','Peak List','Used Peaks')
  xlabel('Wavenumber (cm^{-1})','interpreter','tex')
  ylabel('Normalized Spectrum')

  figure('Name','PeakShiftFit','Color',[1 1 1])
  hh    = zeros(1,3);
  hh(1) = plot(plotdata.xaxis(MapModel.i0),MapModel.foundat,'or'); hold on
  hh(2) = plot(plotdata.axusedpeaks,plotdata.axusedfound,'ob');
  hh(3) = plot(plotdata.xaxis, plotdata.fitline,'-','Color',[0.85 0.325 0.098]);
  legend(hh,'Peak List','Used Peaks','Shift Model')
  legend('AutoUpdate','off')
  gh    = hline;
  gh.Color = [1 1 1]*0.8;
  uistack(gh,'bottom')
  set(gca,'XDir','reverse')
  xlabel('Wavenumber (cm^{-1})','Interpreter','tex')
  ylabel('Peak Shift (cm^{-1})')
end