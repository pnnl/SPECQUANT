function sint = Mapinterp(tstd,smes,c)
%MAPINTERP Interpolates the measured spectrum to the standard axis.
%  
%  The functionality of MAPINTERP depends on input (c).
%   a) If (c) is not input, (smeas) spectra are interpolated to
%      tstd.axisscale{2}.
%   b) If (c) is a lineshape then (smes) spectra from the database are
%      interpolated to tstd.axisscale{2} and convolved with the line shape.
%   c) If (c) is a MapModel structure then (smes) spectra from the
%      field instrument are interpolated and shifted to tstd.axisscale{2}.
%
%  INPUTS: 
%    tstd = 1xNt standard spectrum to map to. See output (tstd) from
%             MAPTOSTANDARDSPECTRUM.
%    smes = KxP set of spectra [class "dataset"].
%             
%  OPTIONAL INPUT:
%       c = structure array (MapModel) OR an instrument line shape.
%
%  OUTPUT:
%    sint = KxNt set of spectra that matches the standard spectrum (tstd).
%
%I/O: sint = Mapinterp(tstd,smes,c);
%
%See Also: MAPTOSTANDARDSPECTRUM

if nargin<3
  sint    = interp1(smes.axisscale{2}(:),smes.data', ...
              tstd.axisscale{2}(:),'spline',0)'; 
else
  if isstruct(c)
    % Assumes it is a MapModel (structure). (smes) is interpolated and
    %  shifted to tstd.axisscale{2}
    sint    = interp1(smes.axisscale{2}(:),smes.data', ...
                tstd.axisscale{2}(:)+c.shiftfns(:),'spline',0)'; 
  else
    % Assumes is is a lineshape (double)
    sint    = interp1(smes.axisscale{2}(:),smes.data', ...
                tstd.axisscale{2}(:),'spline',0)';
    sint    = convline(sint,c);
  end
end

% Create DSO with axisscale{2}            
sint      = copydsfields(tstd,dataset(sint),2);

if ~isempty(smes.label{1})
  lbl     = mat2cell(smes.label{1},ones(size(smes,1),1),size(smes.label{1},2));
else
  lbl     = cell(size(smes,1),1);
end
for ii=1:size(smes,1)
  lbl{ii} = [lbl{ii},' Intrp'];
end
sint.label{1} = lbl;
sint.name = [smes.name,' Intrp']; 
