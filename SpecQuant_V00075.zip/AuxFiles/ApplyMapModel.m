function speci = ApplyMapModel(spec,MapModel,apshift)
% ApplyMapModel Applies a MAPTOSTANDARDSPECTRUM MapModel
%
%  INPUTS:
%        spec = MxN set of sepctra to shift and interpolate using a
%                 MapModel created by MAPTOSTANDARDSPECTRUM [class: DataSet].
%    MapModel = structure array output by MAPTOSTANDARDSPECTRUM.
%
%  OPTIONAL INPUT:
%     apshift = [ {true} | false ] governs the application of shifting.
%               apshift = true, ApplyMapModel applies axis shifting
%                 and interpolation.
%                 speci.name  = [spec.name,'is'];
%               apshift = false, ApplyMapModel applies only axis 
%                 interpolation. This is used to trim standard (database)
%                 spectra to the wavelength scale range of the measured
%                 spectra [i.e., the MapModel axis scale].
%                 speci.name  = [spec.name,'i'];
%
%  OUTPUT:
%       speci = shifted spectra interpolated to the MapModel axis scale.
%
%I/O: speci = ApplyMapModel(spec,MapModel,apshift);
%
%See also: MAPTOSTANDARDSPECTRUM

% 3/3/22 added speci.include{2} = MapModel.inc2;

if nargin<3
  apshift  = true;
end

if apshift %Input (spec) is Field Instrument to be shifted and interpolated
  speci = interp1(spec.axisscale{2}(:),spec.data', ...
            MapModel.axaxis(:)+MapModel.shiftfns(:),'spline',0)'; %Shifting
  speci = copydsfields(spec,dataset(speci),1);     
  speci.name  = [spec.name,'si'];
else    %Input (spec) is Master Instrument using only interpolation
  speci = interp1(spec.axisscale{2}(:),spec.data', ...
            MapModel.axaxis(:),'spline',0)';  % No Shifting
  speci = copydsfields(spec,dataset(speci),1);
  speci.name  = [spec.name,'i'];
end
speci.axisscale{2}     = MapModel.axaxis;
speci.axisscalename{2} = spec.axisscalename{2};
speci.include{2}       = MapModel.incl2;

end %ApplyMapModel