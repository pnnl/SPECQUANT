function wts = SetWeights(smes,tlim)
%SETWEIGHTS sets the weighting for least-squares fitting
%  O(c) = (x-Sc)'*diag(wts.^2)*(x-Sc).
%  See: P. M. Chu, F. R. Guenther, G. C. Rhoderick, and W. J. Lafferty.,
%  "The NIST Quantitative Infrared Database," J. Res. Natl. Inst. Stand. 
%  Technol. 104, 59 (1999)
%
%  INPUT:
%   smes = MxN measured spectra in absorbance (DataSet Object).
%
%  OPTIONAL INPUT:
%   tlim = minimum transmittance: weights for T<tlim are set to 0.
%          {default: tlim = 0.02}.
%
%  OUTPUT:
%    wts = MxN set of weights corresponding to (smes) (DataSet Object).
%
%I/O: wts = SetWeights(smes,tlim);

if nargin<2
  tlim  = 0.02;
end

wts   = smes;                                         %copy DataSet fields to wts
wts.data                            = 10.^-smes.data; %wts = 1/T
wts.data(smes.data>(-log10(tlim)))  = 0;              %wts(A>-log10(tlim)) = 0
wts.data(wts.data>1)                = 1;              %ensure 0<=wts<=1