function [spec,temp] = read_PNNL_GasPhase_spec(s,ax)
%READ_PNNL_GASPHASE_SPEC Reads SPC files.
%  Reads spectra from the PNNL gas phase data base.
%
%  INPUTS:
%      s = Kx1 cell array of full path name of PNNL gas phase spectra
%          to read. Each cell includes the full path name.
%
%  OPTIONAL INPUT:
%     ax = axis scale in wavenumbers 
%          If (ax) is not supplied, the axis scale from the first spectrum
%            in the list in (s) is used as the common axis scale.
%          If (ax) is supplied the desirec spectrum is interpolated to the
%            given axis (ax). [call: interp1(xax(:),dat(:),ax,'spline',0)]
%
%  OUTPUTS:
%   spec = KxN database spectra class "dataset".
%   temp = Kx2 spectra measurement temperature 'C' & 'K' class "double".
%
%I/O: [spec,temp] = read_PNNL_GasPhase_spec(s,ax);

m     = length(s);
if nargin<2
  axflag  = false;
else
  ax      = ax(:);
  n       = length(ax);
  spec    = zeros(m,n);
  axflag  = true;
end

temp  = zeros(m,1);

opts  = spcreadr('options');
opts.nonmatching  = 'none';
opts.waitbar      = 'off';

for i1=1:m
  [dat,xax]   = spcreadr(s{i1},[],[],opts);
  if axflag
    spec(i1,:)  = interp1(xax(:),dat(:),ax,'spline',0)';
  else
    ax          = xax(:);
    n           = length(ax);
    spec        = zeros(m,n);
    spec(i1,:)  = dat;
    axflag      = true;
  end
  i2  = strfind(s{i1},filesep);
  s{i1}       = s{i1}(i2(end)+1:end);
  i2          = strfind(s{i1},'_');
  temp(i1)    = str2double(s{i1}(i2+1:end-1));
end

spec  = dataset(spec);
spec.axisscale{2}     = ax;
spec.axisscalename{2} = 'Wavenumber (cm^{-1})';
spec.label{1}         = s;
spec.description      = char('PNNL Gas Phase Database Spectra', ...
                             'Effective burden of composite spectrum:', ...
                             '1 part-per-million-meter (ppm-meter) at 296 K');
temp  = copydsfields(spec,dataset([temp,temp+273.15]),1);
temp.label{2}         = {'C','K'};
