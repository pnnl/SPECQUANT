function [conc,cerr,res,resw,fitx] = CLS_iSpec(x,stdc,wts,temp,pres,pathlength,cconind)
%CLS_iSPEC estimates concentration and estimation error
%  CLS_iSPEC estimates concentration for each row of measurements (x)
%  based on the weighted CLS objective:
%    O(c) = (x'-Sc)'*diag(wts.^2)*(x'-Sc)
%  where x' is a Nx1 transpose of a row of input (x), S is the NxK set of
%  database spectra, 0<wts<1 (1xN) weighting vector, and c is the Kx1 set
%  of concentrations. These estimates correspond to the database
%  temperature, pressure and pathlength. The weighted residuals, e, are
%  estimated as e = (x'-Sc)'*diag(wts), and Q = e'*e is the weighted Q
%  residuals.
%
%  After estimation, the concentrations are modified to account for
%  temperature (T), pressure (P) and pathlength (L) using:
%    C2 = C1*(P2/T2)*(T1/P1)
%  where C1 is at 1 atm and 296K for the Database. 
%  The output (c) corresponds to C2.
%
%  The estimation error is output in (cerr) estimated as
%     cerr = sqrt(sigma^2*diag(inv(S'diag(wts.^2)*S)))
%  where
%     sigma^2 = (N/(N-K))*(e'*e)/(w'*w)
%  is an estimate of the channel residuals (noise).
%
%  INPUTS:
%            x = measured spectra (MxN) [class DataSet]. (x) corresponds to
%                the M measured spectra at N spectral channels that have been
%                interpolated and shifted to match the data base spectra.
%         stdc = database spectra (KxN) [class DataSet] where K is the
%                number of analyte spectra.
%          wts = weighting matrix for weighted CLS (MxN) 0<wts<1 (See: SetWeights).
%         temp = T, temperature of the measured sample (K) (scalar).
%         pres = P, pressure of the measured sample (atm) (scalar).
%   pathlength = L, measurement pathlength (m) (scalar).
%      cconind = governs nonnegativity (1xK) with entries 0 & 1: 1 indicates
%                nonnegative estimates, 0 indicates non-negativity is relaxed.
%
%  OUTPUTS:
%         conc = estimated concentrations (Mx(K+1)) [class DataSet].
%                Columns 1:K correspond to analytes concentrations at the
%                measurement T, P and L.
%                Column K+1 is the weighted Q residuals.
%                See conc.label{2}.
%         cerr = estimated esimation error (MxK+) [class DataSet].
%                Corresponding to analyte concentrations at the
%                measurement T, P and L.
%                See cerr.label{2}.
%          res = residuals (MxN) = X-CS'.
%         resw = weighted residuals (MxN) = (X-CS').*wts .
%         fitx = (KxNxM) fits in natural (x) measured units.
%
%  Note: squeeze(sum(fitx.data,1))' is an approximation of the baselined
%        input (x).
%
%I/O: [conc,cerr,res,resw,fitx] = CLS_iSpec(x,stdc,wts,temp,pres,pathlength,cconind);

%
%See also: 

m         = size(x);
ncomp     = size(stdc,1);
inc2      = x.include{2};
n         = length(inc2);
if nargin<7
  cconind = [];
end

% Notes: T and P input --> Mx1 vectors for each measurement in x
% database T, P, L should be included for each analyte in stdc
%   if true %place holder for when T,P,L are vectors
%     temp  = temp(ones(m(1)),1);
%     pres  = pres(ones(m(1)),1);
%     pathlength = pathlength(ones(m(1)),1);
%   end
Tstd      = 296; %Database standard temperature (K)
Pstd      = 1;   %Database standard pressure (atm)
Lstd      = 1;   %Database standard pathlength (m)

%% CLS Model
conc      = zeros(m(1),ncomp);
res       = zeros(m);
cerr      = conc;
sgma      = zeros(m(1),1)';
fits      = res;                    %Fit in ppm
fitx      = zeros(ncomp,m(2),m(1)); %Fit in measured units

% Perform weighted CLS
if isempty(cconind)
  for i1=1:m(1)
    w     = wts.data(i1,inc2);                                    %sqrt W
    conc(i1,:)    = (w.*x.data(i1,inc2))/(w.*stdc.data(:,inc2));  %Unconstrained least squares
    fitx(:,inc2,i1) = spdiag(conc(i1,:))*stdc.data(:,inc2);
    fits(i1,inc2) = conc(i1,:)*stdc.data(:,inc2);
    res(i1,inc2)  = x.data(i1,inc2)-fits(i1,inc2);                %Residuals unweighted
    sgma(i1)      = (n/(n-ncomp))*((res(i1,inc2)*w').^2)/(w*w');
    cerr(i1,:)    = sqrt(sgma(i1)./diag(stdc.data(:,inc2)*spdiag(w.^2)*stdc.data(:,inc2)')); %estimation error
  end
else
  for i1=1:m(1)
    w     = wts.data(i1,inc2);
    conc(i1,:)    = fasternnls((w.*stdc.data(:,inc2))',(w.*x.data(i1,inc2))',[],[],[],cconind)'; %NNLS
    fitx(:,inc2,i1) = spdiag(conc(i1,:))*stdc.data(:,inc2);
    fits(i1,inc2) = conc(i1,:)*stdc.data(:,inc2);
    res(i1,inc2)  = x.data(i1,inc2)-fits(i1,inc2); %Residuals unweighted
    sgma(i1)      = (n/(n-ncomp))*((res(i1,inc2)*w').^2)/(w*w');
    cerr(i1,:)    = sqrt(sgma(i1)./diag(stdc.data(:,inc2)*spdiag(w.^2)*stdc.data(:,inc2)')); %estimation error
  end
end

%% Account for T, P and Pathlength: PV = nRT, c=n/V=P/RT
% C2 = C1*(P2/T2)*(T1/P1) where C1 is at 1 atm and 296K
% if vectors spdiag((Tstd./temp)*(Pstd./pres)*(Lstd/pathlength))*conc
conc      = copydsfields(x,dataset((Tstd/temp)*(Pstd/pres)*(Lstd/pathlength)*conc),1);
conc      = copydsfields(stdc',conc,2);
cerr      = copydsfields(conc,dataset((296/temp)*(1/pres)*cerr/pathlength));
concq     = dataset(sum((wts.data(:,inc2).*res(:,inc2)).^2,2));
concq.label{2}  = 'wtQ';
conc      = [conc,concq];
conc.description = 'Concentration (ppm) @ 296K and 1 atm.';
conc.name = 'Concentration (ppm)';
conc.title{2} = conc.name;
cerr.name = 'Estimation Error (ppm)';
cerr.userdata = sgma;
res       = copydsfields(x,dataset(res));
fits(:,inc2)  = conc.data(:,1:ncomp)*stdc.data(:,inc2); %refit to account for T,P&L
fits      = copydsfields(x,dataset(fits));
if m(1)==1
  fitx    = copydsfields(x,dataset(squeeze(fitx)),2);
  fitx    = copydsfields(stdc,fitx,1);
else
  fitx    = copydsfields(x,dataset(fitx),{[1 2],[3 2]});
  fitx    = copydsfields(stdc,fitx,1);
end
ma        = size(x.axisscale(1,:),2);
if ma==1 && isempty(x.axisscale{1})
  res.axisscale{1} = sum(abs(conc.data(:,1:ncomp)),2);
  res.axisscalename{1} = 'Tot(|Conc|)';
else
  res.axisscale{1,ma+1} = sum(abs(conc.data(:,1:ncomp)),2);
  res.axisscalename{1,ma+1} = 'Tot(|Conc|)';
end
resw      = res;
resw.data = resw.data.*wts.data;
