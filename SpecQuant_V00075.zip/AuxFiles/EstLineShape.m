function [y,b,e2,ii,xw,yw] = EstLineShape(sstd,sint,w,options)
%EstLineShape estimates the line shape mapping the standard to the field
%  For a Nx1 standard sepctrum x (sstd'), Nx1 field spectrum y (sint') and
%  window width (w) a regression problem is set up to find (b) that
%  minimizes e'*e
%    Xb = y + e
%  where X is Nxw. Note that the ends corresponding to a non-full window
%  width are ignored in the regression.
%
%  The estimated (b) can be normalized using 1-norm so that (sstd)
%  convolved with (b) transforms the master to 'look like' the field.
%  See CONVLINE.
%
%  INPUTS:
%     sstd  = database (Master) absorbance spectrum [MxN, class "dataset"]
%     sint  = instrument (Field) absorbance spectrum [MxN, class "dataset"]
%        w  = scalar or vector of odd integers defining lineshape widths.
%
%  options  = structure array with the following fields
%      ncomp: governs the estimator {default: ncomp = 1e-4}.
%             If (ncomp)<1 EstLineShape uses Ridge Regression with (ncomp)
%             defining the regularization of x'*x i.e.,
%             ncomp = 1/max(condition number).
%             If (ncomp) a positive integer then EstLineShape uses PLS
%             and (ncomp) is the number of latent variables.
%  algorithm: [ {'RidgeWtd'} | 'Ridge' ]
%             Governs the Ridge Regression algorithm. If 'RidgeWtd', the
%             magnitude of the "ends" of the lineshape (b) are penalized.
%        wts: {[]}; Weights for WLS (see SetWeights). If empty, the minimum
%             weight from (sstd) and (sint) is used.
%             If wts = 1, then no weighting is used.
%         mc: [ {false} | true ] governs if mean-centering is used or not.
%       nnls: [ {'nnls'} | 'none' ] governs imposing nonnegativity on (b).
%       norm: [ {'1norm'} | 'none' ] governs normalization of (b).
%
%  OUTPUTS:
%       y = Master mapped to Field spectrum.
%       b = estimated lineshape for the (w) with minimum RMSE normalized
%           using 1-norm.
%      e2 = RMSE [sqrt(e'*e)] for each window width.
%      iw = index of w at minimum RMSE.
%      xw = sstd rearranged (weighted) xw*b = yw
%      yw = sint (weighted)
%
%I/O: [y,b,e2,iw,xw,yw] = EstLineShape(sstd,sint,w,options);
%I/O: options = EstLineShape('options');
%
%See also: CONVLINE, PLS, SETWEIGHTS

% Notes:
% Use just the peaks found in MapModel?
% If using PLS, y could also be windowed.
% Might add a smoothness penalty
% Line shape equality penalty
% Window width penalty

%% Check Inputs
if ischar(sstd) %Help, Demo, Options
  options       = [];
  options.name  = 'options';
  options.plots = 'final';        % Governs plots to make
  options.ncomp = 1;              % PLS (integer>0), Ridge (0<scalar<1)
  options.algorithm = 'RidgeWtd'; % [{'ridge'} | 'ridgewtd' ]
  options.wts   = [];             % Governs use of SetWeights
  options.mc    = false;          % Governs mean-centering
  options.nnls  = 'nnls';         % [ {'nnls'} | 'none' ]
  options.norm  = '1norm';        % [ {'1norm'} | 'none' ]
  
  if nargout==0
    evriio(mfilename,sstd,options)
  else
    y     = evriio(mfilename,sstd,options);
  end
  return
end
if nargin<4
  options = EstLineShape('options');
end
options   = reconopts(options,mfilename);

if nargin<3
  w       = 7;
end

m         = size(sstd);
if size(sint,1)~=m(1)
  error('Sizes of (sstd) and (sint) must be the same.')
end
if ~isscalar(w) && ~isvec(w)
  error('Input(w) must be scalar or vector of integers.')
end

%% File options fields
if isempty(options.wts) % Set Weights
%   options.wts = SetWeights(sstd);
%   options.wts = options.wts.data';
  wtt     = SetWeights(sint);
  wtt     = wtt.data';
%   options.wts = min([options.wts(:),wtt(:)],[],2);

  options.wts = wtt(:);
elseif options.wts==1
  options.wts = ones(prod(m),1);
else
  options.wts = options.wts(:);
end
if isempty(options.mc) % Set Mean-Centering
  options.mc  = false;
end

%% Estimate the line shape
nw        = length(w); 
e2        = inf(1,nw);                            % RMSE over window width

if nw>1      
  for ii=1:nw  % eval over multiple w
    [~,e2(ii)]  = regressXy(sstd,sint,w(ii),options);
  end
%   add a small penalty to e2 = e2+ a*(1:nw)
  [~,ii]  = min(e2);                              %reuse variable ii
else
  ii      = 1;
end
[b,~,xw,yw] = regressXy(sstd,sint,w(ii),options); %finishing step
y         = convline(sstd,b');
end %EstLineShape

function [b,e2,xw,yw] = regressXy(sstd,sint,w,options)
%REGRESSXY estimates line shape for a single window width
%  INPUTS
%    sstd  = database (Master) absorbance spectrum [MxN, class "dataset"]
%    sint  = instrument (Field) absorbance spectrum [MxN, class "dataset"]
%       w  = is an integer scalar
% options  = structure array with the following fields:
%    ncomp: 
%algorithm: 'Ridge'; %[{   'Ridgewtd'
%      wts:
%       mc:
% 
%  OUTPUTS:
%       b  = wx1 line shape (normalized to 1-norm).
%      e2  = RMSE
%
%I/O: [b,e2,xw,yw] = regressXy(sstd,sint,w,ncomp,wts,mc);

p         = floor(w/2);
m         = size(sstd);

%% Populate y-block
y         = sint.data';
y         = y(:);
if options.mc
  y       = mncn(y);
end
yw        = options.wts.*y;
%% Populate x-block
x         = zeros(m(2)+2*p,w,m(1));
for i0=1:m(1)
  for i1=1:w
    x(i1:i1+m(2)-1,w+1-i1,i0) = sstd.data(i0,:)';
  end
end
x         = x(p+1:end-p,:,:);
x         = reshape(permute(x,[1 3 2]),prod(m),w);
if options.mc
  x       = mncn(x);
end
xw        = spdiag(options.wts)*x;

%% Estimate line shape
options.nnls = 'nnls';
if options.ncomp>=1
  b       = simpls(xw,yw,options.ncomp,struct('display','off'));
  b       = b(options.ncomp,:);
else
  c       = svds(xw'*xw,1)*options.ncomp; %*spdiag(w)
  switch lower(options.algorithm)
  case 'ridge'
    switch lower(options.nnls)
    case 'nnls'
      b   = fasternnls(xw'*xw+c,xw'*yw); %Ridge Regression
    case 'none'
      [u,s] = svd(xw'*xw+c,'vector');
      b   = u'*spdiag(1./s)*u*xw'*yw;
    otherwise
      error('Input (options.nnls) not recognized.')
    end
  case 'ridgewtd'
    wb    = 1-peakgaussian([1 0 p/4],-p:p);
    switch lower(options.nnls)
    case 'nnls'
      b   = fasternnls(xw'*xw+c*spdiag(wb),xw'*yw); %Ridge Regression Penalized
    case 'none'
      [u,s] = svd(xw'*xw+c*spdiag(wb),'vector');
      b   = u'*spdiag(1./s)*u*xw'*yw;
    otherwise
      error('Input (options.nnls) not recognized.')
    end
  end
end
b         = b(:);
e2        = rmse(xw*b,yw);
switch options.norm
case '1norm'
  b         = normaliz(b',[],1)';
case 'none'
  %do nothing
otherwise
  error('Input (options.nnls) not recognized.')
end
% 

end %regressXy